__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['Gui']

from .App import App
