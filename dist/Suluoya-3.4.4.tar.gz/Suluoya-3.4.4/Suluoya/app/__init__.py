__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['App','app']

from .App import App,app
