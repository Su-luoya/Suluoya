# Suluoya

| **[ReadMe](https://www.wolai.com/suluoya/qctn96iZkw9pv6fwshiGeZ)** | [Github1s](https://github1s.com/Su-luoya/Suluoya) | **[PyPi](https://pypi.org/project/Suluoya/)** |
| :----------------------------------------------------------: | :-----------------------------------------------: | :-------------------------------------------: |

```python
import Suluoya as sly
sly.welcome()
```

