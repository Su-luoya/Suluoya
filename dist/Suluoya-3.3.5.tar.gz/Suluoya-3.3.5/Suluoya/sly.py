from pprint import pprint as print
import pretty_errors

def welcome():
    print('Welcome to use Suluoya!')
