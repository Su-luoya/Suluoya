__name__ = "Suluoya"
__author__ = 'Suluoya'
__all__ = ['Markovitz']


from .Markovitz import Markovitz
from .Kline import SyntheticIndex
